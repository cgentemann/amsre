====================
cerform installation
====================


Requirements
============

Your Python package manager should handle most of the dependencies by himself, but there are some gotchas:

- Numpy is required by the setup.py scripts of other modules, so it must be installed beforehand (see https://github.com/pypa/pip/issues/25)::

    pip install numpy==1.7.1

- the Ifremer cerbere library is required

cerform
=======


Just use your package manager to perform installation::

    pip install .
