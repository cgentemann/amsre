=======
cerform
=======

A collection of package and tools complementary to cerbere for the computation
of some geophysical quantities, conversions, etc...
