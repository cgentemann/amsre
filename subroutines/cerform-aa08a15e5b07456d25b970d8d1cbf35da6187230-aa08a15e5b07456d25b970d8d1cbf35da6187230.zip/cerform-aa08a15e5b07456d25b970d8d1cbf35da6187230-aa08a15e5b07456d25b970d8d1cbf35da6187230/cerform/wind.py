# encoding: utf-8
"""
cerbere.science.wind
====================

Routines for computing properties of ocean wind data

:copyright: Copyright 2013 Ifremer / Cersat.
:license: Released under GPL v3 license, see :ref:`license`.

.. sectionauthor:: Jeff Piolle <jfpiolle@ifremer.fr>
.. codeauthor:: Jeff Piolle <jfpiolle@ifremer.fr>
"""
import numpy


def uv2dir(u, v):
    """direction from northward - v - and eastward - u - components.
    direction is returned with ocean convention (where the wind goes to)
    """
    wdir = (numpy.arctan2(u, v) * 180 / numpy.pi) % 360
    return wdir


def meteo2ocean(direction):
    """convert to ocean direction convention (where the wind goes to)"""
    return (direction + 180.) % 360
