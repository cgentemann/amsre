import math


def computeDephValueByFofonoff( p_presValue, p_latitudeValue):

    #********************************************************************
    #// Depth in meters from pressure in decibars using Saunders and
    #// Fofonoff's method.
    #//
    #// Deep_sea rs., 1976, 23, 109-111.
    #// Formula refitted for 1980 equation of state units
    #//
    #// Pressure        P        Decibars
    #// Latitude        Lat        Degrees
    #// Depth        Depth            Meters
    #//
    #// Check value :
    #// Depth= 9712.653 M for P= 10000 Decibars, Latitude= 30 Deg
    #//
    #// Above for standard ocean: T= 0 Deg Celsius; S= 35 (PSS-78)
    #//********************************************************************

    l_p = 0.0
    l_lat = 0.0
    l_x = 0.0
    l_gr = 0.0        # Gravity variation with Latitude :
    # Anon (1970) bulletin geodesique
    l_depth = 0.0
    
    l_p = p_presValue
    l_lat = p_latitudeValue
    
    l_x = math.sin(l_lat / 57.29578)
    l_x = l_x * l_x
    l_gr = 9.780318 * (1.0 + (5.2788E-3 + 2.36E-5 * l_x) * l_x) + 1.092E-6 * l_p
    l_depth = (((-1.82E-15 * l_p + 2.279E-10) * l_p - 2.2512E-5) * l_p + 9.72659) * l_p
        
    l_depth = l_depth / l_gr

    return l_depth
