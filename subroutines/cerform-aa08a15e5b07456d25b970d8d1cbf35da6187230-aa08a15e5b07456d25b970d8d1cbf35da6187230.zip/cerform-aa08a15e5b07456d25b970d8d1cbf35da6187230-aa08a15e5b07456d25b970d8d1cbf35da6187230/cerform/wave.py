# encoding: utf-8
"""
cerbere.science.wave
=========================================

Routines for computing properties of ocean wave data

:copyright: Copyright 2013 Ifremer / Cersat.
:license: Released under GPL v3 license, see :ref:`license`.

.. sectionauthor:: Jeff Piolle <jfpiolle@ifremer.fr>
.. codeauthor:: Jeff Piolle <jfpiolle@ifremer.fr>
"""
import numpy


def wavelength2period(wlength, depth=1e6):
    k = 2. * numpy.pi / wlength
    km = 363.
    g = 9.81
    omega = numpy.sqrt(g * k * (numpy.tanh(k * depth) + (k / km) * (k / km)))
    period = 2. * numpy.pi / omega
    return period

def period2wavelength(period):
    '''return wavelength in [m]
    input period (in [sec])'''
    g = 9.81
    wavelength = (g*period**2)/(2. * numpy.pi)
    return wavelength

def r1r2_to_sth1sth2(alpha1, alpha2, r1, r2):
    if r1 == None:
        stheta1 = None
    else:
        stheta1 = numpy.degrees(numpy.sqrt(abs(2. * (1 - r1))))
    if r2 == None:
        stheta2 = None
    else:
        stheta2 = numpy.degrees(numpy.sqrt(abs(0.5 * (1 - r2))))
    return (alpha1, alpha2, stheta1, stheta2)


def moments2dirspread(a1, b1, a2, b2):
    if a1 == None or b1 == None:
        r1 = None
        theta1 = None
    else:
        r1 = numpy.sqrt(a1 * a1 + b1 * b1)
        theta1 = numpy.fmod(numpy.degrees(numpy.arctan2(b1, a1)), 360)
    if a2 == None or b2 == None:
        r2 = None
        theta2 = None
    else:
        r2 = numpy.sqrt(a2 * a2 + b2 * b2)
        theta2 = numpy.fmod(numpy.degrees(0.5 * numpy.arctan2(b2, a2)), 180)
    return r1r2_to_sth1sth2(theta1, theta2, r1, r2)



KEY_VARIABLES = ['wave_frequency_spectrum_spectral_density','wave_directional_spectrum_spectral_density','significant_wave_height',\
                 'average_wave_period','dominant_wave_direction','dominant_wave_period',\
                 'maximum_wave_height','maximum_wave_steepness','maximum_height_wave_period',\
                 'average_wave_direction','dominant_wave_spreading','wind_wave_significant_wave_height',\
                 'swell_significant_wave_height','wind_wave_average_wave_period','swell_average_wave_period'\
                 'wind_wave_average_wave_direction','swell_average_wave_direction']
DIRECTIONAL_VARIABLES = ['wave_directional_spectrum_spectral_density','dominant_wave_direction','average_wave_direction','dominant_wave_spreading','wind_wave_average_wave_direction','swell_average_wave_direction']
