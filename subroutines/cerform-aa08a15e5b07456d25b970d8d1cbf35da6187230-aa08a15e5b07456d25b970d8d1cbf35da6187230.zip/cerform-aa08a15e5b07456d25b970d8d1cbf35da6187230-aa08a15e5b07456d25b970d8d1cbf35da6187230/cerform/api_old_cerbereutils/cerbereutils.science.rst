science Package
===============

:mod:`science` Package
----------------------

.. automodule:: cerbereutils.science
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`zenital` Module
---------------------

.. automodule:: cerbereutils.science.zenital
    :members:
    :undoc-members:
    :show-inheritance:

