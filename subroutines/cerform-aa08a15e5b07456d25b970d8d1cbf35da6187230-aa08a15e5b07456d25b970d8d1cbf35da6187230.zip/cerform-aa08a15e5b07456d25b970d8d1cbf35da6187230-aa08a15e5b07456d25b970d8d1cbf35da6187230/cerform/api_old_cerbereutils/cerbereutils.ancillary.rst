ancillary package
=================

:mod:`ancillary` Package
------------------------

.. automodule:: cerbereutils.ancillary
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`icemask` Module
---------------------
.. automodule:: cerbereutils.ancillary.icemask
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`landmask` Module
----------------------
.. automodule:: cerbereutils.ancillary.landmask
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tide` Module
------------------
.. automodule:: cerbereutils.ancillary.tide
    :members:
    :undoc-members:
    :show-inheritance:

