plot Package
=============

:mod:`plot` Package
-------------------

.. automodule:: cerbereutils.plot
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`mapping` Module
---------------------

.. automodule:: cerbereutils.plot.mapping
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`palette` Module
---------------------

.. automodule:: cerbereutils.plot.palette
    :members:
    :undoc-members:
    :show-inheritance:

