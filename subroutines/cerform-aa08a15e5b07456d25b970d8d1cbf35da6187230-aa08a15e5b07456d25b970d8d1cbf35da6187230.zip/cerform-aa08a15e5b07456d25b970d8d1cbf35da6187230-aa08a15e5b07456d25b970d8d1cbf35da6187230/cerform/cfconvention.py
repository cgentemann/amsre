
# matching table between Cersat names and CF standard names
STANDARDNAME={
            'air_pressure_at_sea_level':'air_pressure_at_sea_level',
            'air_pressure':'air_pressure',
            
            'wind_speed':'wind_speed',
            'wind_direction':'wind_to_direction',
            'wind_gust':'wind_speed_of_gust',
            
            'dominant_wave_period':'sea_surface_wave_period_at_variance_spectral_density_maximum',
            'significant_wave_height':'sea_surface_wave_significant_height',
            
            'sea_surface_temperature':'sea_surface_temperature',
            'air_temperature':'air_temperature',
            'dew_point_temperature':'dew_point_temperature',
            }

def get_convention():
    return 'CF-1.6'


def get_standardname( vname ):
    if STANDARDNAME.has_key( vname ):
        return STANDARDNAME[vname]
    else:
        return None