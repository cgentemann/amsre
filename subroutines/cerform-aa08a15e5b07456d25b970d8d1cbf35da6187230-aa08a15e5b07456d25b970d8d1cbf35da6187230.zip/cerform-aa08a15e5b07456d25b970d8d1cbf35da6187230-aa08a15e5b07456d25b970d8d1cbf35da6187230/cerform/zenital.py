# encoding: utf-8
# pylint: disable=R0914
"""
cerbere.science.zenital
=======================

Provides helper functions for calculating solar zenital angles.

:copyright: Copyright 2013 Ifremer / Cersat.
:license: Released under GPL v3 license, see :ref:`license`.

.. sectionauthor:: Jeff Piolle <jfpiolle@ifremer.fr>
.. codeauthor:: Jeff Piolle <jfpiolle@ifremer.fr>
"""
import datetime
import copy

from numpy import pi, arcsin, sin, cos, arccos
from netCDF4 import num2date, date2num
from cerbere.datamodel.field import Field
from cerbere.datamodel.variable import Variable


def sun_zenital_angle(time, lat, lon):
    '''
    compute sun zenital angle from time and location

    Args:
        time (datetime or tuple): time
        lat (float): latitude, in degrees
        lon (float): longitude, in degrees

    Returns:
        the calculated sun zenital angle, in degrees
    '''
    if isinstance(time, datetime.datetime):
        day = time.timetuple()[7]
        hour = time.hour
        minute = time.minute
    elif isinstance(time, tuple):
        day, hour, minute = time

    w_angle = 2 * pi / 365.25
    jquan = day
    sin1 = sin(w_angle * (jquan - 2.))
    decl = arcsin(0.398 * sin(w_angle * (jquan - 81. + 2. * sin1)))
    eqtm = 0.128 * sin1 + 0.164 * sin(2. * w_angle * (jquan + 10.))
    htsv = hour + minute / 60. - eqtm + lon / 15.
    anghor = pi * (htsv - 12.) / 12.
    lat_rad = lat * pi/180.
    sla = sin(lat_rad)
    cla = cos(lat_rad)
    sde = sin(decl)
    cde = cos(decl)
    cah = cos(anghor)
    zensol = arccos(sla * sde + cla * cde * cah)
    return zensol * 180 / pi


def get_sun_zenital_angle(feature):
    """
    Return the sun zenital angle field matching the feature.
    """
    times = feature.get_times()
    mintime = num2date(times.min(), feature.get_time_units())
    time0 = date2num(datetime.datetime(mintime.year, 1, 1, 0, 0, 0),
                     feature.get_time_units())
    # get julian day from beginning of the year
    times = times - time0
    if 'seconds' in feature.get_time_units():
        days = (times / 86400.).astype('int32')
        hours = ((times % 86400.) / 3600.).astype('int32')
        minutes = (((times % 86400.) % 3600.) / 60.).astype('int32')
    elif 'hours' in feature.get_time_units():
        days = (times / 24.).astype('int32')
        hours = (times % 24.).astype('int32')
        minutes = (((times % 24.) - hours) * 60.).astype('int32')
    elif 'days' in feature.get_time_units():
        days = (times).astype('int32')
        hours = ((times - days) * 24.).astype('int32')
        minutes = ((((times - days) * 24.) - hours) * 60.).astype('int32')
    else:
        raise Exception("Time units not manage by this function: ",
                        feature.get_time_units())
    zensol = sun_zenital_angle((days, hours, minutes),
                               feature.get_lat(),
                               feature.get_lon()
                               )
    field = Field(
        Variable('sun_zenital_angle', 'sun zenital angle'),
        dimensions=copy.copy(
            feature.get_geolocation_field('lon').dimensions),
        values=zensol,
        units="angular_degree"
        )
    return field
