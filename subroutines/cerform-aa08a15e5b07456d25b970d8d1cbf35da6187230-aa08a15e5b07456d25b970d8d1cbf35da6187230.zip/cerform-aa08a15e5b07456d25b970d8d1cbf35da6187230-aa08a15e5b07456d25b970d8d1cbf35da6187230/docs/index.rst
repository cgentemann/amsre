=======================================
Welcome to cerform documentation!
=======================================

*cerform* is a collection of modules to perform scientific operations on
physical parameters in different topics:
  
  * wave parameters
  * wind parameters
  * flux parameters

It provides both modules and handy command-line tools.

Reference documentation
=======================
.. toctree::
   :maxdepth: 2

   
   ./api/index.rst
   

Tutorials
=========
.. toctree::
   :maxdepth: 2

   ./tuto/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


