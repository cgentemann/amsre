.. cerform documentation master file, created by
   sphinx-quickstart on Tue Dec 10 15:47:17 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Cerform modules description
=============================================

Contents:

.. toctree::
   :maxdepth: 4

   cerform
   setup