flux_library
============

The flux computing library from cerform allows to compute air-sea flux parameters from bulk inputs variables (SST, T, Q, Qs, U,...).
Parameterization available are:
  * COARE3 (Fairall et al. 2003)
  * COARE4 (Fairall et al. 2011)
  * LKB (Liu, Katsaros and Bussinger (1979))
  * Large & Pond (1981, 1982)
  * Smith (1988)
  
disclaimer:
-----------

This library is mainly a transcoding of existing matlab(r) and Fortran functions.
Some of them have been turn into vectorial computing (COARE3).
  
sources:
--------
+--------+--------------------+-----------------------------------------------------------------------------+
| method |      source code   |          documentation                                                      |
+========+====================+=============================================================================+
| COARE3 | cor30a.m           | ftp://ftp1.esrl.noaa.gov/users/cfairall/wcrp_wgsf/computer_programs/cor3_0/ |
+--------+--------------------+-----------------------------------------------------------------------------+
| COARE4 | coare40vn.m        |                                                                             |
+--------+--------------------+-----------------------------------------------------------------------------+
| Smith  |                    |                                                                             |
+--------+--------------------+-----------------------------------------------------------------------------+

usage:
------

.. code-block:: python

  from cerform.flux.coare3 import coare3
  inputs = {'u':12.5,'ts':289.48,'Q':4.56}
  res = coare3(inputs)

validation:
-----------

.. image:: ../images/tst3_python_flux_coare_all_curves.png
   :height: 500px
   :width: 650 px
   :scale: 60 %
   :alt: validation python COARE3 and COARE4 against Matlab version