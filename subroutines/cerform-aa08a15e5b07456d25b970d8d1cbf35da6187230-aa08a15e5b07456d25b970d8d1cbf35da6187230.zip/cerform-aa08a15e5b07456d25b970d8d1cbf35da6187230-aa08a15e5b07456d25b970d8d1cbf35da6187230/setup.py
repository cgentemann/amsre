#-*- coding: utf-8 -*-
"""
cerform
=======

A collection of package and tools complementary to cerbere for the computation
of some geophysical quantities, conversions, etc...

:copyright: Copyright 2015 Ifremer / Cersat.
:license: Released under GPL v3 license, see :ref:`license`.

.. sectionauthor:: Jeff Piolle <jfpiolle@ifremer.fr>
.. codeauthor:: Jeff Piolle <jfpiolle@ifremer.fr>
"""
# from setuptools import setup
from distutils.core import setup
# from distutils.extension import Extension
# from Cython.Distutils import build_ext
# from numpy import get_include


# The name an location of Cython modules
EXT_MODULES = []

setup(
    zip_safe=False,
    name='cerform',
    version='0.1.0',
    author='Jeff Piolle <jfpiolle@ifremer.fr>',
    author_email='jfpiolle@ifremer.fr',
    url = "http://cersat.ifremer.fr",
    packages=['cerform'],
    scripts=[],
    license='LICENSE.txt',
    description='A collection of package and tools complementary to cerbere for the computation of some geophysical quantities, conversions, etc...',
    install_requires=[
        'numpy>=1.7.1'
        ],
    package_data={},
#     cmdclass = {'build_ext': build_ext},
    ext_modules = EXT_MODULES,
#     include_dirs=[get_include()]
)
